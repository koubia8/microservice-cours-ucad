package sn.ucad.informatique.soa.msstage;

import lombok.Data;

@Data
public class Etudiant {
    private String numeroEtudiant;
    private String nom;
    private String prenom;
}
