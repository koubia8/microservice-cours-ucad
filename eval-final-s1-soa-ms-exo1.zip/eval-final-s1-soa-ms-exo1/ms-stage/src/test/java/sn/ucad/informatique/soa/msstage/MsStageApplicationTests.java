package sn.ucad.informatique.soa.msstage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsStageApplicationTests {

	@Test
	void contextLoads() {
	}

}
